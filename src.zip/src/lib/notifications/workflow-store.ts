import "server-only";

import { createAdminClient } from "@/lib/supabase/admin";
import type {
  CreateNotificationInput,
  CreateWorkflowTaskInput,
  MarkNotificationResolvedInput,
  NotificationDedupeInput,
  ResolveWorkflowTaskInput,
} from "./types";

const ALLOWED_HREF_PREFIXES = [
  "/owner",
  "/manager",
  "/crm",
  "/staff-portal",
  "/driver",
  "/utility",
] as const;

const OPEN_NOTIFICATION_STATUSES = ["unread", "read"] as const;
const OPEN_TASK_STATUSES = ["open", "in_progress"] as const;

function cleanSegment(value: string | null | undefined, fallback: string): string {
  return (value?.trim() || fallback).toLowerCase().replace(/[^a-z0-9_.-]+/g, "_");
}

function validateHref(href: string | null | undefined): string | null {
  if (!href) return null;
  return ALLOWED_HREF_PREFIXES.some((prefix) => href === prefix || href.startsWith(`${prefix}/`))
    ? href
    : null;
}

function isUniqueViolation(error: { code?: string } | null): boolean {
  return error?.code === "23505";
}

export function buildNotificationDedupeKey(input: NotificationDedupeInput): string {
  const eventOrTask = input.eventType ?? input.taskType ?? "signal";
  const recipient = input.recipientStaffId
    ? `staff.${input.recipientStaffId}`
    : `role.${input.recipientRole ?? input.workspaceScope}`;

  return [
    cleanSegment(input.entityType, "global"),
    cleanSegment(input.entityId, "none"),
    cleanSegment(eventOrTask, "signal"),
    cleanSegment(recipient, "workspace"),
    cleanSegment(input.workspaceScope, "workspace"),
    cleanSegment(input.branchId, "global"),
  ].join(":");
}

function notificationDedupeKey(input: CreateNotificationInput): string {
  return input.dedupeKey ?? buildNotificationDedupeKey({
    branchId: input.branchId,
    workspaceScope: input.targetWorkspace,
    recipientStaffId: input.recipientStaffId,
    recipientRole: input.targetRole,
    eventType: input.type,
    entityType: input.entityType,
    entityId: input.entityId,
  });
}

function taskDedupeKey(input: CreateWorkflowTaskInput | ResolveWorkflowTaskInput): string {
  return input.dedupeKey ?? buildNotificationDedupeKey({
    branchId: input.branchId,
    workspaceScope: input.workspaceScope,
    recipientStaffId: input.assignedToStaffId,
    recipientRole: input.assignedToRole,
    taskType: input.taskType,
    entityType: input.entityType,
    entityId: input.entityId,
  });
}

export async function createOrUpdateNotification(
  input: CreateNotificationInput
): Promise<void> {
  const admin = createAdminClient();
  const dedupeKey = notificationDedupeKey(input);
  const now = new Date().toISOString();
  const payload = {
    branch_id: input.branchId ?? null,
    target_workspace: input.targetWorkspace,
    target_role: input.targetRole ?? null,
    recipient_staff_id: input.recipientStaffId ?? null,
    actor_staff_id: input.actorStaffId ?? null,
    type: input.type,
    title: input.title,
    body: input.body ?? null,
    entity_type: input.entityType ?? null,
    entity_id: input.entityId ?? null,
    action_href: validateHref(input.actionHref),
    priority: input.priority ?? "normal",
    status: "unread",
    read_at: null,
    resolved_at: null,
    requires_action: input.requiresAction ?? false,
    dedupe_key: dedupeKey,
    metadata: input.metadata ?? {},
    created_at: now,
  };

  const existing = await admin
    .from("workspace_notifications")
    .select("id")
    .eq("dedupe_key", dedupeKey)
    .in("status", [...OPEN_NOTIFICATION_STATUSES])
    .maybeSingle();

  if (existing.data) {
    const { error } = await admin
      .from("workspace_notifications")
      .update(payload)
      .eq("id", existing.data.id);
    if (error) console.error("[notifications] update failed", error.message);
    return;
  }

  const { error } = await admin.from("workspace_notifications").insert(payload);
  if (!error) return;
  if (isUniqueViolation(error)) {
    await admin.from("workspace_notifications").update(payload).eq("dedupe_key", dedupeKey);
    return;
  }
  console.error("[notifications] insert failed", { type: input.type, error: error.message });
}

export async function createOrUpdateWorkflowTask(
  input: CreateWorkflowTaskInput
): Promise<void> {
  const admin = createAdminClient();
  const dedupeKey = taskDedupeKey(input);
  const payload = {
    branch_id: input.branchId ?? null,
    workspace_scope: input.workspaceScope,
    assigned_to_staff_id: input.assignedToStaffId ?? null,
    assigned_to_role: input.assignedToRole ?? null,
    task_type: input.taskType,
    title: input.title,
    body: input.body ?? null,
    entity_type: input.entityType,
    entity_id: input.entityId,
    action_href: validateHref(input.actionHref),
    priority: input.priority ?? "normal",
    status: "open",
    due_at: input.dueAt ?? null,
    completed_at: null,
    completed_by_staff_id: null,
    dedupe_key: dedupeKey,
    metadata: input.metadata ?? {},
  };

  const existing = await admin
    .from("workflow_tasks")
    .select("id")
    .eq("dedupe_key", dedupeKey)
    .in("status", [...OPEN_TASK_STATUSES])
    .maybeSingle();

  if (existing.data) {
    const { error } = await admin.from("workflow_tasks").update(payload).eq("id", existing.data.id);
    if (error) console.error("[workflow_tasks] update failed", error.message);
    return;
  }

  const { error } = await admin.from("workflow_tasks").insert(payload);
  if (!error) return;
  if (isUniqueViolation(error)) {
    await admin.from("workflow_tasks").update(payload).eq("dedupe_key", dedupeKey);
    return;
  }
  console.error("[workflow_tasks] insert failed", { taskType: input.taskType, error: error.message });
}

export async function resolveWorkflowTask(input: ResolveWorkflowTaskInput): Promise<void> {
  const admin = createAdminClient();
  const { error } = await admin
    .from("workflow_tasks")
    .update({
      status: input.status ?? "completed",
      completed_at: new Date().toISOString(),
      completed_by_staff_id: input.completedByStaffId ?? null,
    })
    .eq("dedupe_key", taskDedupeKey(input))
    .in("status", [...OPEN_TASK_STATUSES]);
  if (error) console.error("[workflow_tasks] resolve failed", error.message);
}

export async function markNotificationResolved(
  input: MarkNotificationResolvedInput
): Promise<void> {
  const admin = createAdminClient();
  let query = admin
    .from("workspace_notifications")
    .update({ status: "resolved", resolved_at: new Date().toISOString() })
    .in("status", [...OPEN_NOTIFICATION_STATUSES]);

  if (input.dedupeKey) query = query.eq("dedupe_key", input.dedupeKey);
  if (input.entityType) query = query.eq("entity_type", input.entityType);
  if (input.entityId) query = query.eq("entity_id", input.entityId);
  if (input.targetWorkspace) query = query.eq("target_workspace", input.targetWorkspace);
  if (input.type) query = query.eq("type", input.type);
  if (input.branchId) query = query.eq("branch_id", input.branchId);
  if (input.recipientStaffId) query = query.eq("recipient_staff_id", input.recipientStaffId);
  if (input.targetRole) query = query.eq("target_role", input.targetRole);

  const { error } = await query;
  if (error) console.error("[notifications] resolve failed", error.message);
}
