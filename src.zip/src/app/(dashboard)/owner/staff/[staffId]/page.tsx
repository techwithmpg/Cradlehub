import { notFound } from "next/navigation";
import { PageHeader } from "@/components/features/dashboard/page-header";
import { getAllStaff } from "@/lib/queries/staff";
import { getAllBranches } from "@/lib/queries/branches";
import { getAllServices } from "@/lib/queries/services";
import { getStaffServices } from "@/lib/queries/staff";
import { getStaffAdminName } from "@/lib/staff/display-name";
import type { Database } from "@/types/supabase";
import { StaffEditForm } from "@/components/features/staff/staff-edit-form";
import type { StaffMember } from "@/components/features/staff/staff-management-utils";

type StaffRow = Database["public"]["Tables"]["staff"]["Row"];
type BranchRow = Database["public"]["Tables"]["branches"]["Row"];
type ServiceRow = Database["public"]["Tables"]["services"]["Row"] & {
  service_categories: { id: string; name: string } | null;
};
type BranchRel = { id: string; name: string } | { id: string; name: string }[] | null;
type StaffWithBranch = StaffRow & { branches: BranchRel };

function readBranchName(relation: BranchRel): string {
  if (!relation) return "Unknown branch";
  if (Array.isArray(relation)) return relation[0]?.name ?? "Unknown branch";
  return relation.name;
}

export default async function StaffDetailPage({
  params,
}: {
  params: Promise<{ staffId: string }>;
}) {
  const { staffId } = await params;
  const [allStaff, branches, services] = await Promise.all([
    getAllStaff(),
    getAllBranches(),
    getAllServices(),
  ]);
  const typedStaff = allStaff as StaffWithBranch[];
  const typedBranches = branches as BranchRow[];
  const typedServices = services as ServiceRow[];
  const staffMember = typedStaff.find((s) => s.id === staffId);

  if (!staffMember) {
    notFound();
  }

  const staffServiceIds = await getStaffServices(staffId);

  return (
    <div style={{ maxWidth: 760 }}>
      <PageHeader
        title={getStaffAdminName(staffMember)}
        description={`${readBranchName(staffMember.branches)} · ${staffMember.system_role}`}
      />
      <StaffEditForm
        staffMember={staffMember as unknown as StaffMember}
        branches={typedBranches}
        services={typedServices}
        staffServiceIds={staffServiceIds}
        workspaceContext="owner"
      />
    </div>
  );
}
