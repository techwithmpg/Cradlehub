import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { searchCustomers } from "@/lib/queries/customers";

export async function GET(request: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: me } = await supabase
    .from("staff")
    .select("system_role, branch_id")
    .eq("auth_user_id", user.id)
    .single();

  const allowedRoles = ["owner", "manager", "crm", "csr", "csr_head", "csr_staff"];
  if (!me || !allowedRoles.includes(me.system_role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const q = request.nextUrl.searchParams.get("q") ?? "";
  if (q.length < 2) {
    return NextResponse.json({ customers: [] });
  }

  const branchId = me.system_role === "owner" ? null : me.branch_id;
  const customers = await searchCustomers(q, branchId);
  return NextResponse.json({ customers });
}
