"use client";

import {
  STAFF_CELL_WIDTH_PX,
  ROW_HEIGHT_PX,
  formatScheduleTime,
} from "@/lib/utils/schedule-timeline";
import type { DailyScheduleStaffRow } from "@/lib/queries/schedule";

type StaffCellProps = {
  staff: DailyScheduleStaffRow;
};

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function formatStaffLabel(staff: DailyScheduleStaffRow): string {
  if (!staff.staff_tier) return "Service Staff";
  const tier = staff.staff_tier.toLowerCase();
  if (tier === "senior") return "Senior Therapist";
  if (tier === "mid") return "Therapist";
  if (tier === "junior") return "Junior Therapist";
  return staff.staff_tier.charAt(0).toUpperCase() + staff.staff_tier.slice(1);
}

export function ScheduleStaffCell({ staff }: StaffCellProps) {
  const isOff = !staff.work_start || !staff.work_end;

  return (
    <div
      style={{
        width: STAFF_CELL_WIDTH_PX,
        height: ROW_HEIGHT_PX,
        flexShrink: 0,
        backgroundColor: isOff ? "var(--cs-bg)" : "var(--cs-surface)",
        borderRight: "1px solid var(--cs-border)",
        borderBottom: "1px solid var(--cs-border)",
        padding: "10px 12px",
        display: "flex",
        alignItems: "center",
        gap: "0.625rem",
        position: "sticky",
        left: 0,
        zIndex: 4,
      }}
    >
      {/* Avatar */}
      <div
        style={{
          width: 34,
          height: 34,
          borderRadius: "50%",
          backgroundColor: isOff ? "#E5E0DB" : "#E8F5E9",
          color: isOff ? "#8A7A6A" : "#4A7C59",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "0.75rem",
          fontWeight: 700,
          flexShrink: 0,
          fontFamily: "var(--font-playfair, serif)",
        }}
      >
        {getInitials(staff.staff_name)}
      </div>

      {/* Info */}
      <div style={{ minWidth: 0, flex: 1 }}>
        <div
          style={{
            fontSize: "0.8125rem",
            fontWeight: 600,
            color: isOff ? "var(--cs-text-muted)" : "var(--cs-text)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            lineHeight: 1.3,
          }}
        >
          {staff.staff_name}
        </div>
        <div
          style={{
            fontSize: "0.6875rem",
            color: "var(--cs-text-muted)",
            marginTop: 2,
            lineHeight: 1.3,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {formatStaffLabel(staff)}
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 4,
            marginTop: 4,
          }}
        >
          <span
            style={{
              width: 6,
              height: 6,
              borderRadius: "50%",
              backgroundColor: isOff ? "#BDBDBD" : "#4A7C59",
              flexShrink: 0,
            }}
          />
          <span
            style={{
              fontSize: "0.6875rem",
              color: isOff ? "var(--cs-text-muted)" : "#4A7C59",
              fontWeight: 500,
            }}
          >
            {isOff
              ? "Off today"
              : `${formatScheduleTime(staff.work_start!)} – ${formatScheduleTime(staff.work_end!)}`}
          </span>
        </div>
      </div>
    </div>
  );
}
